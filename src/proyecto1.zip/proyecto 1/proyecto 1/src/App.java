import javafx.application.Application;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;


public class App extends Application {
    public static void main(String[] args) throws Exception {
        launch(args);
    }

    @Override
    public void start(Stage primerEstado) {
       primerEstado.setTitle("Sistema de Inventario");

        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: gray");

        Label Titulo = new Label("Registro de Visitantes");
        Titulo.setFont(Font.font("Arial", FontWeight.BOLD, 26));
        Titulo.setStyle("-fx-text-fill: #00008b.");
        HBox rot = new HBox(Titulo);
        rot.setAlignment(Pos.CENTER);
        root.getChildren().add(rot);

        GridPane form = new GridPane();
        form.setHgap(15);  // para definir el espacio horizontal
        form.setVgap(12); //para definir el espacio vertical
        form.setPadding(new Insets(10));
        
        

        TextField nombre = new TextField();
        nombre.setPromptText("Ej Haniel Suarez");

        TextField cedula = new TextField();
        cedula.setPromptText("000-0000000-0");

        TextField telefono = new TextField();
        telefono.setPromptText("809-577-3012");

        TextField motivo = new TextField();
        motivo.setPromptText("Ej. proceso Academico");

        TextField persona = new TextField();
        persona.setPromptText("Ej Decano de Carrera");


        DatePicker dt = new DatePicker();
        dt.setMaxWidth(Double.MAX_VALUE);

        ComboBox<String> TipoVisita = new ComboBox<>();//sirve para llenar de opciones un menu
        TipoVisita.setPromptText("elija una opcion");
        TipoVisita.setItems(FXCollections.observableArrayList(//observableArrayList esta directamente conectado con la interfaz grafica y permite que si en un futuro quieres borrar algo de la lista se actualiza la pantalla sin tener que recargar el componente 
            "Padre/Madre",
            "Estudiante",
            "suplidor",
            "Invitador"
            
        ));// setItems es el metodo que le asigna a la lista completa de elementos que se mostraran en el menu desplegable
        TipoVisita.setMaxWidth(Double.MAX_VALUE);

        ToggleGroup tgDocumento = new ToggleGroup();
        RadioButton ced = new RadioButton("Cedula");
        ced.setToggleGroup(tgDocumento);
        RadioButton pas = new RadioButton("Pasaporte");
        pas.setToggleGroup(tgDocumento);
        RadioButton car = new RadioButton("Carnet");
        car.setToggleGroup(tgDocumento);

        HBox HbDocumento = new HBox(50, ced, pas, car);
        HbDocumento.setAlignment(Pos.CENTER_LEFT);

        form.add(new Label("Nombre Completo:"), 0, 0);
        form.add(nombre, 1, 0);

        form.add(new Label("Cedula:"), 0, 1);
        form.add(cedula, 1, 1);

        form.add(new Label("Telefono:"), 0, 2);
        form.add(telefono, 1, 2);

        form.add(new Label("Tipos de Visitantes:"), 2, 2);
        form.add(TipoVisita, 3, 2);

        form.add(new Label("Documentos Entregados:"), 0, 4);
        form.add(HbDocumento, 1, 4, 3, 1);

        form.add(new Label("Motivo de Visita:"), 2, 0); // se arreglo las cordenadas de motivo de visita en el arreglo
        form.add(motivo, 3, 0);

        form.add(new Label("Persona a Visitar:"), 2, 3);
        form.add(persona, 3, 3);

        form.add(new Label("Fecha:"), 2, 1);
        form.add(dt, 3, 1);

        ColumnConstraints col1 = new ColumnConstraints(130);
        ColumnConstraints col2 = new ColumnConstraints(180);
        ColumnConstraints col3 = new ColumnConstraints(130);
        ColumnConstraints col4 = new ColumnConstraints(180);
        form.getColumnConstraints().addAll(col1, col2, col3, col4);

        root.getChildren().add(form);
        
        Button reg = new Button("Registrar");
        reg.setStyle("-fx-background-color: #2ecc71; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 8 20;");// el primer numero de padding (8) controla el espacio vertical y el (20) el espacio horizontal

        Button lim = new Button("Limpiar");
        lim.setStyle("-fx-background-color: #f1c40f; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 8 20;");

        Button can = new Button("Cancelar");
        can.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 8 20;");

        HBox bot = new HBox(15, reg, lim, can);
        bot.setAlignment(Pos.CENTER_RIGHT);
        root.getChildren().add(bot);

        TableView<Object> tbVis = new TableView<>();

        TableColumn<Object, String> Nombre = new TableColumn<>("Nombre");
        TableColumn<Object, String> Cedula = new TableColumn<>("Cedula");
        TableColumn<Object, String> Tipo = new TableColumn<>("Tipo");
        TableColumn<Object, String> Persona = new TableColumn<>("Persona");
        TableColumn<Object, String> Fecha = new TableColumn<>("Fecha");
        
        
        Nombre.setCellValueFactory(new PropertyValueFactory<>("Nombre"));
        Cedula.setCellValueFactory(new PropertyValueFactory<>("cedula"));
        Tipo.setCellValueFactory(new PropertyValueFactory<>("Tipo"));
        Persona.setCellValueFactory(new PropertyValueFactory<>("Persona"));
        Fecha.setCellValueFactory(new PropertyValueFactory<>("Fecha")); 

        Nombre.prefWidthProperty().bind(tbVis.widthProperty().multiply(0.25));
        Cedula.prefWidthProperty().bind(tbVis.widthProperty().multiply(0.15));
        Tipo.prefWidthProperty().bind(tbVis.widthProperty().multiply(0.15));
        Persona.prefWidthProperty().bind(tbVis.widthProperty().multiply(0.30));
        Fecha.prefWidthProperty().bind(tbVis.widthProperty().multiply(0.14));

        tbVis.getColumns().addAll(Nombre, Cedula, Tipo, Persona, Fecha);
        tbVis.setPrefHeight(200);

        root.getChildren().add(tbVis);

        Scene scene = new Scene(root, 720, 560);
        primerEstado.setScene(scene);
        primerEstado.setResizable(false); // Mantiene la interfaz fija y ordenada
        primerEstado.show();
    }
    
    }

