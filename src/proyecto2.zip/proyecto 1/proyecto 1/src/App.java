import javafx.application.Application;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.control.CheckBox;


public class App extends Application {
    public static void main(String[] args) throws Exception {
        launch(args);
    }

    @Override
    public void start(Stage primerEstado) {
       primerEstado.setTitle("Sistema de Inventario");

        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: gray");

        Label Titulo = new Label("Sistema de Inventario");
        Titulo.setFont(Font.font("Arial", FontWeight.BOLD, 26));
        Titulo.setStyle("-fx-text-fill: #00008b.");
        HBox rot = new HBox(Titulo);
        rot.setAlignment(Pos.CENTER);
        root.getChildren().add(rot);

        GridPane form = new GridPane();
        form.setHgap(15);  // para definir el espacio horizontal
        form.setVgap(12); //para definir el espacio vertical
        form.setPadding(new Insets(10));
        
        

        TextField codigo = new TextField();
        codigo.setPromptText("Ej. 001");

        TextField nombre = new TextField();
        nombre.setPromptText("Ej. producto x");

        TextField categoria = new TextField();
        categoria.setPromptText("Ej. categoria x");

        TextField precio = new TextField();
        precio.setPromptText("Ej. 1000.00");

        TextField cantidad = new TextField();
        cantidad.setPromptText("Ej. 10");

        TextField Proveedor = new TextField();
        Proveedor.setPromptText("Ej. proveedor x");

        ComboBox<String> EstadoPro = new ComboBox<>();//sirve para llenar de opciones un menu
        EstadoPro.setPromptText("elije una opcion");
        EstadoPro.setMaxWidth(Double.MAX_VALUE);
        EstadoPro.setItems(FXCollections.observableArrayList(//observableArrayList esta directamente conectado con la interfaz grafica y permite que si en un futuro quieres borrar algo de la lista se actualiza la pantalla sin tener que recargar el componente 
            "Disponible",
            "Agotado",
            "Bajo Inventario"
            
        ));

        form.add(new Label("Codigo del producto:"), 0, 0);
        form.add(codigo, 1, 0);

        form.add(new Label("Nombre del producto:"), 0, 1);
        form.add(nombre, 1, 1);

        form.add(new Label("Categoria:"), 0, 2);
        form.add(categoria, 1, 2);

        form.add(new Label("Precio:"), 2, 1);
        form.add(precio, 3, 1);

        form.add(new Label("Cantidad:"), 2, 2);
        form.add(cantidad, 3, 2);

        form.add(new Label("Proveedor:"), 2, 0); 
        form.add(Proveedor, 3, 0);

        form.add(new Label("Estado del producto:"), 0, 3);
        form.add(EstadoPro, 1, 3);



        ColumnConstraints col1 = new ColumnConstraints(130);
        ColumnConstraints col2 = new ColumnConstraints(180);
        ColumnConstraints col3 = new ColumnConstraints(130);
        ColumnConstraints col4 = new ColumnConstraints(180);
        
        form.getColumnConstraints().addAll(col1, col2, col3, col4);

        root.getChildren().add(form);
        
        Button guar = new Button("Guardar");
        guar.setStyle("-fx-background-color: #2ecc71; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 8 20;");// el primer numero de padding (8) controla el espacio vertical y el (20) el espacio horizontal

        Button edi = new Button("Editar");
        edi.setStyle("-fx-background-color: #d3a902; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 8 20;");

        Button eli = new Button("Eliminar");
        eli.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 8 20;");

        Button bus = new Button("Buscar");
        bus.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 8 20;");

        HBox bot = new HBox(15, guar, edi , eli, bus);
        bot.setAlignment(Pos.CENTER_RIGHT);
        root.getChildren().add(bot);

        TableView<Object> tbVis = new TableView<>();

        TableColumn<Object, String> Codigo = new TableColumn<>("Codigo");
        TableColumn<Object, String> Producto = new TableColumn<>("Producto");
        TableColumn<Object, String> Categoria = new TableColumn<>("Categoria");
        TableColumn<Object, String> Precio = new TableColumn<>("Precio");
        TableColumn<Object, String> Cantidad = new TableColumn<>("cantidad");
        TableColumn<Object, String> Estado = new TableColumn<>("Estado");
        
        
        Codigo.setCellValueFactory(new PropertyValueFactory<>("Codigo"));
        Producto.setCellValueFactory(new PropertyValueFactory<>("Producto"));
        Categoria.setCellValueFactory(new PropertyValueFactory<>("Categoria"));
        Precio.setCellValueFactory(new PropertyValueFactory<>("Precio"));
        Cantidad.setCellValueFactory(new PropertyValueFactory<>("Cantidad"));
        Estado.setCellValueFactory(new PropertyValueFactory<>("Estado"));

        Codigo.prefWidthProperty().bind(tbVis.widthProperty().multiply(0.15));
        Producto.prefWidthProperty().bind(tbVis.widthProperty().multiply(0.25));
        Categoria.prefWidthProperty().bind(tbVis.widthProperty().multiply(0.15));
        Precio.prefWidthProperty().bind(tbVis.widthProperty().multiply(0.15));
        Cantidad.prefWidthProperty().bind(tbVis.widthProperty().multiply(0.15));
        Estado.prefWidthProperty().bind(tbVis.widthProperty().multiply(0.15));

        tbVis.getColumns().addAll(Codigo, Producto, Categoria, Precio, Cantidad, Estado);
        tbVis.setPrefHeight(200);

        root.getChildren().add(tbVis);

        CheckBox sel = new CheckBox("Producto perecedero");
        sel.setSelected(false);
        sel.setStyle("-fx-text-fill: black; -fx-font-weight: bold;");
        boolean isSelected = sel.isSelected();
        
        CheckBox sel2 = new CheckBox("Producto importado");
        sel2.setSelected(false);
        sel2.setStyle("-fx-text-fill: black; -fx-font-weight: bold;");
        boolean isSelected2 = sel2.isSelected();

        CheckBox sel3 =  new CheckBox("Producto refrigerado");
        sel3.setSelected(false);
        sel3.setStyle("-fx-text-fill: black; -fx-font-weight: bold;");
        boolean isSelected3 = sel3.isSelected();

        HBox ch = new HBox(20, sel, sel2, sel3);
        ch.setAlignment(Pos.CENTER_LEFT);

        VBox checkboxesContainer = new VBox(10, sel, sel2, sel3);
        checkboxesContainer.setAlignment(Pos.CENTER_LEFT);

        form.add(new Label("Opciones Adicionales"), 0, 4);
        form.add(checkboxesContainer, 0, 5, 4, 1);

        Scene scene = new Scene(root, 780, 660);
        primerEstado.setScene(scene);
        primerEstado.setResizable(false); // Mantiene la interfaz fija y ordenada
        primerEstado.show();
    }
    
    }

