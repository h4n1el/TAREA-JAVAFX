import javafx.application.Application;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.control.CheckBox;


public class App extends Application {
    public static void main(String[] args) throws Exception {
        launch(args);
    }

    @Override
    public void start(Stage primerEstado) {
       primerEstado.setTitle("perfil de Estudiante");

       Label Titulo = new Label("Perfil De Estudiante");
       Titulo.setFont(Font.font("ROBOTO", FontWeight.BOLD, 24));
       Titulo.setStyle("-fx-text-fill: DarkBlue");

       Circle cir = new Circle(55);
       cir.setFill(Color.web("lightgreen"));
       cir.setStroke(Color.web("DarkBlue"));// este metodo establece el color del borde del círculo
       cir.setStrokeWidth(4);// este metodo establece el grosor del borde del círculo

       Label foto = new Label("Sin Foto");
       foto.setStyle("-fx-text-fill: DarkBlue; -fx-font-weight: bold;");
       
       StackPane fot = new StackPane(cir, foto);
       fot.setAlignment(Pos.CENTER);
      
       


       VBox ver = new VBox(25);
       ver.setStyle("-fx-background-color: white");
       ver.setPadding(new Insets(10));

       HBox hor = new HBox(Titulo);
       hor.setAlignment(Pos.CENTER);
       ver.getChildren().addAll(hor, fot);

       GridPane form = new GridPane();
       form.setHgap(15);
       form.setVgap(15);
       form.setPadding(new Insets(10));

       TextField matricula = new TextField();
       matricula.setPromptText("0000-0000");

       TextField nombre = new TextField();
       nombre.setPromptText("Ej. juan Perez");

       TextField carrera = new TextField();
       carrera.setPromptText("Ej. Ing Sis");

       TextField correo = new TextField();
       correo.setPromptText("Fulanito@gmail.com");

       TextField telefono = new TextField();
       telefono.setPromptText("000-000-000");

       TextField direccion = new TextField();
       direccion.setPromptText("Ciudad, Calle");

       form.add(new Label("Matricula:"), 0, 0);
       form.add(matricula, 0, 1);

       form.add(new Label("Nombre:"), 0, 2);
       form.add(nombre, 0, 3);

       form.add(new Label("Carrera:"), 0, 4);
       form.add(carrera, 0, 5);

       form.add(new Label("Correo Electronico:"), 0, 6);
       form.add(correo, 0, 7);

       form.add(new Label("Telefono:"), 0, 8);
       form.add(telefono, 0, 9);

       form.add(new Label("Direccion:"), 0, 10);
       form.add(direccion, 0, 11);

       ColumnConstraints Cola = new ColumnConstraints(220);
       form.getColumnConstraints().addAll(Cola);
       form.setAlignment(Pos.CENTER);
      


       ver.getChildren().add(form);

       Button guar = new Button("Guardar");
       guar.setStyle("-fx-background-color: green; -fx-text-fill: white; -fx-font-weidght: bold; -fx-padding: 8 20;");

       Button act = new Button("Actualizar");
       act.setStyle("-fx-background-color: blue; -fx-text-fill: white; -fx-font-weidght: bold; -fx-padding: 8 20;");

       Button imp = new Button("imprimir");
       imp.setStyle("-fx-background-color: red; -fx-text-fill: white; -fx-font-weidght: bold; -fx-padding: 8 20;");

       HBox bot = new HBox(20, guar, act, imp);
       bot.setAlignment(Pos.CENTER);
       ver.getChildren().addAll(bot);

       Scene escena = new Scene(ver, 440, 720);
       primerEstado.setScene(escena);
       primerEstado.setResizable(false);
       primerEstado.show();

      
    }
    
    }

